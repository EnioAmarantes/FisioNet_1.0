const editButton = "<span id='edit' onclick='edit(this)' class='material-icons mx-2'>mode_edit</span>";
const delButton = "<span id='delete' onclick='del(this)' class='material-icons mx-2'>delete</span>";
const lookButton = "<span id='look' onclick='look(this)' class='material-icons mx-2'>remove_red_eye</span>";